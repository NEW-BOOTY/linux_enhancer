# linux_enhancer.sh — Enterprise Linux Enhancement (GOD-MODE)

**Author:** Devin B. Royal  
**Script:** `linux_enhancer.sh`  
**Date:** 2025-09-26

## Overview

`linux_enhancer.sh` is an enterprise-grade, modular Bash script designed to perform a full-spectrum enhancement of a Linux system. It includes:

- System update & cleanup (cross-distro support).
- Real-time disk space monitoring with safe cleanup.
- File organization (auto-sort files into type-based folders).
- A terminal system information dashboard.
- Timestamped, optionally encrypted backups and restore support.
- Security hardening (conservative, safe changes).
- System customization presets.
- Auto-correction & self-healing logic.
- Optional cron integration and basic cloud sync hooks.
- Logging, retry logic, and dry-run capability.

## Files

- `linux_enhancer.sh` — executable Bash script (make executable with `chmod +x linux_enhancer.sh`).
- `README.md` — this document.

## Requirements

- Bash (4+ recommended).
- Root / sudo for many operations.
- Common utilities: `tar`, `gzip`, `openssl`, `gpg`, `rsync`, `jq` (the script attempts to auto-install missing tools when possible).
- For GUI notifications: `notify-send`.
- For cloud sync: provider-specific CLI (awscli/rclone/etc.) — not pre-configured by the script.

Tested on: Debian/Ubuntu, RHEL/Fedora (dnf/yum), Arch Linux (pacman), SUSE (zypper). Behavior adapts to available package manager.

## Usage

Basic:

```bash
sudo ./linux_enhancer.sh --auto
